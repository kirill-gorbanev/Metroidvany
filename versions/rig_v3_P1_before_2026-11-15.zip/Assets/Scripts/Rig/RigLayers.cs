using UnityEngine;

namespace Fortress.Rig
{
    /// <summary>Слои физики рига. «Призраки» (невидимые аниматоры людей, CharacterController) сталкиваются только со
    /// статичным миром (пол, стены, помосты) — сквозь всё подвижное они проходят, а в подвижное врезаются настоящие тела.
    /// Тела ригов, табуреты, ящики, бочки, мячи — слой RigBody.</summary>
    public static class RigLayers
    {
        public const int Ghost = 8, Body = 9, Trigger = 2;
        /// <summary>Лучи «что под ногами» и мышь стенда: всё, кроме триггеров и призраков.</summary>
        public const int SolidMask = ~((1 << Trigger) | (1 << Ghost));
        /// <summary>Только статичный мир (без тел и призраков).</summary>
        public const int WorldMask = ~((1 << Trigger) | (1 << Ghost) | (1 << Body));

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void Init()
        {
            Physics.IgnoreLayerCollision(Ghost, Body, true);
            Physics.IgnoreLayerCollision(Ghost, Ghost, true);
        }

        /// <summary>Поставить объект и всех детей с коллайдерами на слой тел.</summary>
        public static void SetBody(GameObject g)
        {
            foreach (var c in g.GetComponentsInChildren<Collider>(true)) c.gameObject.layer = Body;
        }
    }
}
