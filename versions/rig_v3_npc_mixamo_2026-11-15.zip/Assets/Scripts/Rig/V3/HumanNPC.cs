using UnityEngine;

namespace Fortress.Rig.V3
{
    /// <summary>Риг v3, NPC: ходит анимация (клипы Mixamo, root motion), капсула идёт за корнем клипа (HumanMotor.MoveRoot).
    /// Мозг выбирает клип под задачу — так нет скольжения ног и рывков:
    ///   стоит → цель сбоку/сзади: поворот на месте (90° / 180°, клип «доворачивается» до точного угла);
    ///   старт с места (клип Walk_Start без первых долей секунды) → ход (смесь Locomotion по VelX/VelZ, подруливание и обход встречных);
    ///   цель сзади на ходу — разворот 180° на ходу; цель ближе пути остановки — клип Walk_Stop, растянутый точно до точки;
    ///   упёрся в тяжёлое — встал.
    /// Удар (HumanReaction → точка захвата → HumanMotor.Knocked): слабый — только отклик и качание поверх анимации;
    /// сильный — клип удара по направлению толчка (спереди/сзади/слева/справа), путь клипа повёрнут точно по толчку и масштабирован силой.
    /// Висит на модели (рядом с Animator), контроллер — Assets/Rig/Anim/HumanNPC.controller (RigHumanV3Builder).</summary>
    [DefaultExecutionOrder(-45)]
    [RequireComponent(typeof(Animator))]
    public class HumanNPC : MonoBehaviour
    {
        [Header("Ход")]
        [Tooltip("Темп всех клипов (1 — как в клипе: шаг 1.5 м/с)")] public float tempo = 0.9f;
        [Tooltip("Подруливание на ходу (градусы/с)")] public float walkTurnRate = 110f;
        [Tooltip("Цель сбоку больше (градусы) — сначала повернуться на месте")] public float turnInPlace = 50f;
        [Tooltip("Цель сзади больше (градусы) на ходу — разворот на ходу")] public float turnOnTheWay = 140f;
        [Header("Удары")]
        [Tooltip("Скорость центра масс от удара (м/с), с которой играется клип удара")] public float hitThreshold = 0.45f;
        [Tooltip("Скорость центра масс, на которую рассчитан путь клипа удара (м/с)")] public float hitNominal = 0.9f;

        // клипы (замер кривых корня, см. память проекта): длина, где начинается/кончается движение, поворот, путь
        const float WalkV = 1.51f;                   // скорость Walk (м/с)
        const float StartFrom = 0.35f, StartTo = 1.9f, StartSpeed = 1.3f;
        const float StopTravel = 1.13f, StopTo = 2.0f, StopSpeed = 1.15f;
        const float TurnSpeed = 1.2f;

        public enum Mode { Idle, Turn, Start, Walk, Stop, Blocked, Sidestep, Hit }
        public Mode State => mode;
        public bool Busy => mode == Mode.Hit;
        public string Say => mode switch
        {
            Mode.Idle => "стоит", Mode.Turn => "поворот", Mode.Start => "трогается", Mode.Walk => "идёт",
            Mode.Stop => "останавливается", Mode.Blocked => "упёрся", Mode.Sidestep => "уступает", Mode.Hit => "удар: " + hitClip, _ => "",
        };

        Animator anim;
        HumanMotor motor;
        Mode mode = Mode.Idle;
        float modeT, modeLen;
        float turnWarp = 1f, stopWarp = 1f, hitScale = 1f;
        Quaternion hitTurn = Quaternion.identity;
        string hitClip = "";
        float velZ, velX;
        float blockedT, wait;
        int index;
        Vector3 goal;
        bool haveGoal;
        static readonly int VelXId = Animator.StringToHash("VelX"), VelZId = Animator.StringToHash("VelZ");

        static readonly string[] HitClips = { "Hit_Front", "Hit_Back", "Hit_Left", "Hit_Right" };
        readonly System.Collections.Generic.Dictionary<string, Vector3> hitPath = new System.Collections.Generic.Dictionary<string, Vector3>();

        void Awake()
        {
            anim = GetComponent<Animator>();
            motor = GetComponentInParent<HumanMotor>();
            anim.applyRootMotion = true;
            // путь клипов ударов в осях тела (средняя скорость корня клипа)
            if (anim.runtimeAnimatorController)
                foreach (var c in anim.runtimeAnimatorController.animationClips)
                    if (System.Array.IndexOf(HitClips, c.name) >= 0)
                    {
                        Vector3 v = c.averageSpeed; v.y = 0f;
                        if (v.sqrMagnitude > 1e-4f) hitPath[c.name] = v.normalized;
                    }
            if (motor) { motor.rootMotion = true; motor.Knocked += OnKnock; }
        }

        void OnDestroy() { if (motor) motor.Knocked -= OnKnock; }

        void Start()
        {
            tempo *= Random.Range(0.93f, 1.07f);     // люди ходят немного по-разному
            Pick();
        }

        // ---------------------------------------------------------------- цель (обход точек, брожение, «иди туда»)
        void Pick()
        {
            haveGoal = true;
            if (motor.points != null && motor.points.Length > 0) { goal = motor.points[index % motor.points.Length]; index++; }
            else if (motor.radius > 0f) { var r = Random.insideUnitCircle * motor.radius; goal = motor.center + new Vector3(r.x, 0f, r.y); }
            else haveGoal = false;
        }

        bool Target(out Vector3 t, out float arrive)
        {
            arrive = motor.arrive;
            if (motor.goTo.HasValue) { t = motor.goTo.Value; arrive = motor.goToArrive; return true; }
            t = goal;
            return !motor.idle && haveGoal;
        }

        // ---------------------------------------------------------------- решения
        void Update()
        {
            float dt = Time.deltaTime;
            if (dt <= 0f || !motor) return;
            anim.speed = tempo;
            modeT += dt * tempo;
            bool has = Target(out var t, out float arrive);
            Vector3 to = t - motor.transform.position; to.y = 0f;
            float dist = to.magnitude;
            Vector3 fwd = motor.transform.forward; fwd.y = 0f;
            float ang = dist > 1e-3f ? Vector3.SignedAngle(fwd, to, Vector3.up) : 0f;
            motor.Arrived = motor.goTo.HasValue && dist < motor.goToArrive;

            switch (mode)
            {
                case Mode.Idle:
                    velZ = Mathf.MoveTowards(velZ, 0f, 3f * dt);
                    if (!has) break;
                    if (dist <= arrive)
                    {
                        if (motor.goTo.HasValue) break;
                        wait += dt;
                        if (wait > motor.pause) { wait = 0f; Pick(); }
                        break;
                    }
                    if (Mathf.Abs(ang) > turnInPlace) BeginTurn(ang);
                    else if (dist > StopTravel * 0.9f) BeginStart();
                    else BeginWalk(0.6f);                     // близко — пара шагов без разгона
                    break;
                case Mode.Turn:
                    if (modeT >= modeLen)
                    {
                        if (has && dist > arrive) { if (dist > StopTravel * 0.9f) BeginStart(); else BeginWalk(0.6f); }
                        else Go(Mode.Idle, "Locomotion", 0.3f, 0f);
                    }
                    break;
                case Mode.Start:
                    if (!has || dist <= StopTravel) { BeginStop(dist); break; }
                    if (modeT >= modeLen) BeginWalk(WalkV);
                    break;
                case Mode.Walk:
                    if (!has) { BeginStop(StopTravel); break; }
                    if (dist <= StopTravel * Mathf.Max(0.5f, velZ / WalkV)) { BeginStop(dist); break; }
                    if (Mathf.Abs(ang) > turnOnTheWay) { BeginWalkTurn(ang); break; }
                    velZ = Mathf.MoveTowards(velZ, WalkV, 2f * dt);
                    // упёрся: в тяжёлое или стену — встать; в человека — шагнуть вбок (вправо) и идти дальше
                    blockedT = motor.Velocity.magnitude < 0.25f * velZ * tempo ? blockedT + dt : 0f;
                    if (blockedT > 0.35f)
                    {
                        blockedT = 0f;
                        if (motor.BlockedByHeavy) { Go(Mode.Blocked, "Locomotion", 0.25f, 0f); velZ = 0f; }
                        else { mode = Mode.Sidestep; modeT = 0f; }
                    }
                    break;
                case Mode.Sidestep:
                    // смесь Locomotion: шаг вбок вправо (клип уводит чуть вперёд) — обойти встречного
                    velX = Mathf.MoveTowards(velX, 0.95f, 4f * dt);
                    velZ = Mathf.MoveTowards(velZ, 0.6f, 4f * dt);
                    if (modeT > 0.8f) { mode = Mode.Walk; modeT = 0f; }
                    break;
                case Mode.Stop:
                    if (modeT >= modeLen) Go(Mode.Idle, "Locomotion", 0.4f, 0f);
                    break;
                case Mode.Blocked:
                    velZ = 0f;
                    // цель сменилась (повернуть назад) или путь освободился — снова в путь
                    if (has && dist > arrive && (Mathf.Abs(ang) > turnInPlace || modeT > 2.5f)) mode = Mode.Idle;
                    break;
                case Mode.Hit:
                    if (modeT >= modeLen) Go(Mode.Idle, "Locomotion", 0.35f, 0f);
                    break;
            }
            if (mode != Mode.Sidestep) velX = Mathf.MoveTowards(velX, 0f, 4f * dt);
            anim.SetFloat(VelZId, velZ, 0.12f, dt);
            anim.SetFloat(VelXId, velX, 0.12f, dt);
        }

        void Go(Mode m, string state, float fade, float offset)
        {
            mode = m; modeT = 0f;
            anim.CrossFadeInFixedTime(state, fade, 0, offset);
        }

        void BeginTurn(float ang)
        {
            // 90° клипы: −90 / +101; 180° — −173 / +173 (зеркало)
            float clipAng; string st;
            if (Mathf.Abs(ang) > 125f) { st = ang < 0f ? "Turn_Left_180" : "Turn_Right_180"; clipAng = ang < 0f ? -173f : 173f; modeLen = 1.6f / TurnSpeed; }
            else { st = ang < 0f ? "Turn_Left_90" : "Turn_Right_90"; clipAng = ang < 0f ? -90f : 101f; modeLen = 0.9f / TurnSpeed; }
            turnWarp = Mathf.Clamp(ang / clipAng, 0.4f, 1.6f);
            Go(Mode.Turn, st, 0.2f, 0f);
        }

        void BeginStart()
        {
            Go(Mode.Start, "Walk_Start", 0.2f, StartFrom);
            modeLen = (StartTo - StartFrom) / StartSpeed;
            velZ = WalkV;
        }

        void BeginWalk(float v)
        {
            velZ = Mathf.Max(velZ, v);
            Go(Mode.Walk, "Locomotion", 0.35f, 0f);
        }

        void BeginWalkTurn(float ang)
        {
            // клип: +180 вправо за 1 с; влево — зеркало
            turnWarp = Mathf.Clamp(Mathf.Abs(ang) / 180f, 0.6f, 1.1f);
            Go(Mode.Turn, ang > 0f ? "Walk_Turn_180_R" : "Walk_Turn_180_L", 0.2f, 0f);
            modeLen = 0.95f;
        }

        void BeginStop(float remaining)
        {
            stopWarp = Mathf.Clamp(remaining / StopTravel, 0.3f, 1.5f);
            Go(Mode.Stop, "Walk_Stop", 0.25f, 0f);
            modeLen = StopTo / StopSpeed;
            velZ = 0f;
        }

        /// <summary>Сильный удар: клип по направлению толчка (в осях тела), путь — точно по толчку, длина — по силе.</summary>
        void OnKnock(Vector3 dv)
        {
            dv.y = 0f;
            float s = dv.magnitude;
            if (s < hitThreshold) return;
            // клип, чей путь (в осях тела, клипы Mixamo уводят косо) ближе всего к толчку; путь доворачивается точно по толчку
            Vector3 dir = dv / s, clipDir = -motor.transform.forward;
            float best = -2f;
            foreach (var n in HitClips)
            {
                if (!hitPath.TryGetValue(n, out var local)) continue;
                Vector3 w = motor.transform.rotation * local;
                float dot = Vector3.Dot(w, dir);
                if (dot > best) { best = dot; hitClip = n; clipDir = w; }
            }
            modeLen = hitClip == "Hit_Front" ? 1.15f : hitClip == "Hit_Back" ? 1.1f : 1.2f;
            hitTurn = Quaternion.FromToRotation(clipDir, dir);
            hitScale = Mathf.Clamp(s / hitNominal, 0.5f, 1.6f);
            blockedT = 0f;
            Go(Mode.Hit, hitClip, 0.08f, 0f);
        }

        // ---------------------------------------------------------------- ход: корень клипа → капсула
        void OnAnimatorMove()
        {
            if (!motor) return;
            float dt = Time.deltaTime;
            // корень клипа идёт в осях модели, а модель Quaternius развёрнута внутри капсулы на 180° (смотрит в −Z своего корня):
            // перевести сдвиг в оси капсулы
            Vector3 d = motor.transform.rotation * Quaternion.Inverse(transform.rotation) * anim.deltaPosition;
            float dy = anim.deltaRotation.eulerAngles.y;
            if (dy > 180f) dy -= 360f;
            switch (mode)
            {
                case Mode.Turn:
                    dy *= turnWarp;
                    break;
                case Mode.Start:
                case Mode.Walk:
                {
                    if (mode == Mode.Walk && velX > 0.3f) break;
                    if (Target(out var t, out _))
                    {
                        Vector3 to = t - motor.transform.position; to.y = 0f;
                        if (to.sqrMagnitude > 0.01f)
                        {
                            Vector3 want = motor.SteerAround(to);
                            float a = Vector3.SignedAngle(motor.transform.forward, want, Vector3.up);
                            float lim = walkTurnRate * dt * tempo;
                            dy += Mathf.Clamp(a * 4f * dt, -lim, lim);
                        }
                    }
                    break;
                }
                case Mode.Stop:
                    d *= stopWarp;
                    break;
                case Mode.Hit:
                    d = hitTurn * d * hitScale;
                    dy = 0f;
                    break;
                case Mode.Idle:
                case Mode.Blocked:
                    d *= 0.3f;     // переступания стоя — почти на месте
                    break;
            }
            motor.MoveRoot(d, dy, dt);
        }
    }
}
