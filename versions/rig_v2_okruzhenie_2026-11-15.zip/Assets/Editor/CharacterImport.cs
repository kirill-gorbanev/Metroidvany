using UnityEditor;

namespace Fortress.EditorTools
{
    /// <summary>Импорт людей Quaternius (Assets/Characters): гуманоидный риг (Humanoid, свой аватар),
    /// анимации только из библиотек UAL, текстуры нормалей/ORM/шероховатости — линейные.</summary>
    public class CharacterImport : AssetPostprocessor
    {
        const string Root = "Assets/Characters/";

        void OnPreprocessModel()
        {
            if (!assetPath.StartsWith(Root)) return;
            var mi = (ModelImporter)assetImporter;
            bool anims = assetPath.Contains("/Anim/");
            mi.importCameras = false;
            mi.importLights = false;
            mi.globalScale = 1f;
            // причёски и отдельные части нарядов — неполный скелет: без аватара (кости привяжем к телу по именам)
            bool partial = assetPath.Contains("/Hair/") || assetPath.Contains("/Parts/");
            mi.animationType = partial ? ModelImporterAnimationType.Generic : ModelImporterAnimationType.Human;
            if (!partial) mi.avatarSetup = ModelImporterAvatarSetup.CreateFromThisModel;
            mi.importAnimation = anims;
            mi.isReadable = assetPath.Contains("/Base/");   // из базового тела вырезаем голову для нарядов
            mi.importBlendShapes = !anims;
            mi.materialImportMode = anims ? ModelImporterMaterialImportMode.None : ModelImporterMaterialImportMode.ImportViaMaterialDescription;
            mi.materialSearch = ModelImporterMaterialSearch.RecursiveUp;
            mi.materialName = ModelImporterMaterialName.BasedOnTextureName;
        }

        void OnPreprocessAnimation()
        {
            if (!assetPath.StartsWith(Root) || !assetPath.Contains("/Anim/")) return;
            var mi = (ModelImporter)assetImporter;
            var clips = mi.defaultClipAnimations;
            foreach (var c in clips)
            {
                string n = c.name.ToLowerInvariant();
                c.loopTime = n.Contains("loop") || n.EndsWith("sword_idle");   // в UAL зацикленные помечены _Loop (LayToIdle — нет)
                c.lockRootRotation = true;
                c.lockRootHeightY = true;
                c.lockRootPositionXZ = false;
                c.keepOriginalOrientation = true;
                c.keepOriginalPositionY = true;
            }
            mi.clipAnimations = clips;
        }

        void OnPreprocessTexture()
        {
            if (!assetPath.StartsWith(Root)) return;
            var ti = (TextureImporter)assetImporter;
            if (assetPath.Contains("_Normal")) ti.textureType = TextureImporterType.NormalMap;
            if (assetPath.Contains("_ORM") || assetPath.Contains("_Normal") || assetPath.Contains("_Roughness")) ti.sRGBTexture = false;
            ti.maxTextureSize = 2048;
        }
    }
}
