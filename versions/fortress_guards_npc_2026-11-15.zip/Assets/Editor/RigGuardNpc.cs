using System.Linq;
using Fortress.Guards;
using Fortress.Rig.V3;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.AI;

namespace Fortress.EditorTools
{
    /// <summary>Стража замка — люди рига v3 (HumanNPC_*, клипы Mixamo) вместо капсул-заглушек.
    /// Заглушку (GuardPatrol + NavMeshAgent + капсула со «шлемом») меняет на NPC с теми же обходом, скоростями и кроватью:
    /// навмеш прокладывает путь, человек идёт своими клипами. Вызывается из GridSceneBuilder.CreateGuards и меню для открытой сцены.</summary>
    public static class RigGuardNpc
    {
        const string Pf = "Assets/Rig/Prefabs/HumanNPC_";

        public static bool Available => AssetDatabase.LoadAssetAtPath<GameObject>(Pf + "Ranger_Male.prefab");

        static GameObject PrefabFor(string role, int k)
        {
            string n = role switch
            {
                "jailer" => "Peasant_Bearded",
                "watch" or "archer" => "Ranger_Female",
                "patrol" => "Ranger_Male",
                _ => k % 2 == 0 ? "Ranger_Male" : "Peasant_Bearded",
            };
            return AssetDatabase.LoadAssetAtPath<GameObject>(Pf + n + ".prefab");
        }

        /// <summary>Заменить заглушку на NPC; вернуть нового стража (или заглушку, если NPC нет).</summary>
        public static GameObject Convert(GameObject placeholder, int k)
        {
            var old = placeholder.GetComponent<GuardPatrol>();
            if (!old || placeholder.GetComponentInChildren<HumanNPC>()) return placeholder;
            var pf = PrefabFor(old.role, k);
            if (!pf) return placeholder;
            var go = (GameObject)PrefabUtility.InstantiatePrefab(pf, placeholder.transform.parent);
            go.name = placeholder.name;
            go.transform.SetPositionAndRotation(placeholder.transform.position, placeholder.transform.rotation);

            var oldAgent = placeholder.GetComponent<NavMeshAgent>();
            var ag = go.AddComponent<NavMeshAgent>();
            ag.agentTypeID = oldAgent ? oldAgent.agentTypeID : 0;
            ag.radius = 0.3f; ag.height = 1.8f; ag.baseOffset = 0f;
            ag.speed = old.walkSpeed;
            ag.avoidancePriority = oldAgent ? oldAgent.avoidancePriority : 50;

            var gp = go.AddComponent<GuardPatrol>();
            EditorUtility.CopySerialized(old, gp);
            gp.body = null;
            if (old.sleeping)
            {
                // заглушка лежала на верху кровати вдоль длинной стороны: центр, ось, высота верха
                gp.bedCenter = placeholder.transform.position;
                gp.bedAlong = placeholder.transform.forward;
                gp.bedTop = placeholder.transform.position.y + 0.05f;
                ag.enabled = false;
            }
            Object.DestroyImmediate(placeholder);
            return go;
        }

        [MenuItem("Fortress/Guards/Replace placeholders with NPC (open scene)")]
        public static void ReplaceInOpenScene()
        {
            if (EditorApplication.isPlaying) { Debug.LogWarning("[Guards] сначала выйди из Play"); return; }
            if (!Available) { Debug.LogWarning("[Guards] нет префабов HumanNPC_* — меню Fortress/Rig/Build Humans v3"); return; }
            var list = Object.FindObjectsByType<GuardPatrol>(FindObjectsSortMode.None).Where(g => !g.GetComponentInChildren<HumanNPC>()).OrderBy(g => g.guardId).ToList();
            int k = 0;
            foreach (var g in list) Convert(g.gameObject, k++);
            var scene = EditorSceneManager.GetActiveScene();
            EditorSceneManager.MarkSceneDirty(scene);
            EditorSceneManager.SaveScene(scene);
            Debug.Log($"[Guards] стражей заменено на людей: {list.Count} ({scene.path})");
        }
    }
}
